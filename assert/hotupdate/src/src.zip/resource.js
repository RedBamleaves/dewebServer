//这里加载初始页面。即热更新页面
var res = {
    //HelloWorld_png : "res/HelloWorld.png",
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}
