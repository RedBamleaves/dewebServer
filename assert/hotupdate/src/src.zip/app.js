
var HelloWorldLayer = cc.Layer.extend({
    sprite:null,
    ctor:function () {
        //////////////////////////////
        // 1. super init first
        this._super();
        /////////////////////////////
        // 2. add a menu item with "X" image, which is clicked to quit the program
        //    you may modify it.
        // ask the window size
        var size = cc.winSize;
        /////////////////////////////
        // 3. add your codes below...
        // add a label shows "Hello World"
        // create and initialize a label
        var helloLabel = new cc.LabelTTF("Hello World", "Arial", 38);
        // position the label on the center of the screen
        helloLabel.x = size.width / 2;
        helloLabel.y = size.height / 2 + 200;
        // add the label as a child to this layer
        this.addChild(helloLabel, 5);

        // add "HelloWorld" splash screen"
        this.sprite = new cc.Sprite("res/HelloWorld.png");
        this.sprite.attr({
            x: size.width / 2,
            y: size.height / 2
        });
        this.addChild(this.sprite, 0);
        UILayerLoading.openWnd(this);
        ExitTipsWnd.openWnd(this,'搞事情啊！').setConfirm_cb(function () {
            cc.log('一起来搞事情啊！');
        });

        ipTools.ReqGroposition(function (msg) {
            cc.log(msg);
        });

        FeedbackTips.showTips('都来搞事情啊！',this);

        setTimeout(function () {
           // TP_Scroll.FlyTo(Tp_Address.TP_Depoker);
        }, 2 * 1000);



        return true;
    }
});


var HelloWorldScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

var login = function () {
    const userName = 'robot10106';
    const password = 'password';
    const nVesion = 1;

    //连接服务器
    let strIP = '192.168.1.179';
    let nPort = '5555';//'6666' youxi
    MsgTools.connectionServer(strIP,nPort);

    let msgtool = MsgTools.create();
    msgtool.setOpcode(c2s_PROTOCOL.C2S_ACCOUNT_LOGIN);
    msgtool.push_buffer_int(nVesion,32)
        .push_buffer_constchar(userName)
        .push_buffer_constchar(password)
        .SendSelf();
};
