/**
 * Created by Administrator on 2017/2/11.
 */
let failCount = 0;
let maxFailCount = 1;   //max errors
const JSLIST_PATH = 'src/jsList.js';
const P_MANIFEST = 'res/project.manifest';
/**
 * hot update
 */
let AssetsManagerLoaderScene = cc.Scene.extend({
    _am:null,
    _progress:null,
    _percent:0,
    run : function(){
        if (!cc.sys.isNative) {
            this.loadGame();
            return;
        }

        let layer = new cc.Layer();
        this.addChild(layer);

        let effect = cc.createEffect("res/effect_xydz",'xydz',2.5,26,true,false,2,0.5);
        effect.setAnchorPoint(cc.p(0.5,0.5));
        effect.setPosition(cc.winSize.width/2,cc.winSize.height/2);
        this.addChild(effect,1);

        let layer_bkg = new cc.Sprite('res/Depoker_Bkg@2x.png');
        layer_bkg.setAnchorPoint(cc.p(0.5,0.5));
        layer_bkg.setPosition(cc.winSize.width/2,cc.winSize.height/2);
        this.addChild(layer_bkg,1);

        let progress_di = new cc.Sprite('res/update_progress_di.png');
        progress_di.setAnchorPoint(cc.p(0.5,0.5));
        progress_di.setPosition(cc.winSize.width/2,cc.winSize.height/2 - 200);
        this.addChild(progress_di,2);

        this._progress = new cc.ProgressTimer(new cc.Sprite("res/update_progress_tiao.png"));
        this._progress.setAnchorPoint(cc.p(0.5,0.5));
        this._progress.setPosition(cc.p(progress_di.getContentSize().width/2,progress_di.getContentSize().height/2));
        this._progress.setType(cc.ProgressTimer.TYPE_BAR);
        this._progress.setMidpoint(cc.p(0,0));
        this._progress.setBarChangeRate(cc.p(1, 0));
        this._progress.setPercentage(0);
        progress_di.addChild(this._progress,1);

        //It belongs to 'update' from here!
        let storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./");
        cc.log("storagePath is " + storagePath);
        this._am = new jsb.AssetsManager(P_MANIFEST, storagePath);
        this._am.retain();
        if (!this._am.getLocalManifest().isLoaded())//if (true)
        {
            cc.log("Fail to update assets, step skipped.");
            this.loadGame();
        }
        else
        {
            let that = this;
            let listener = new jsb.EventListenerAssetsManager(this._am, function(event) {
                switch (event.getEventCode()){
                    case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                        cc.log("No local manifest file found, skip assets update.");
                        that.scheduleOnce(that.loadGame,1.5);
                        break;
                    case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                        that._percent = event.getPercent().toFixed(2);
                        cc.log('that._percent = ' + that._percent);
                        let msg = event.getMessage();
                        if (msg) {
                            cc.log('msg : ' + msg);
                        }
                        break;
                    case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
                    case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                        cc.log("Fail to download manifest file, update skipped.");
                        that.scheduleOnce(that.loadGame,1.5);
                        break;
                    case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                        cc.log("ALREADY_UP_TO_DATE.");
                        that.scheduleOnce(that.loadGame,1.5);
                        break;
                    case jsb.EventAssetsManager.UPDATE_FINISHED:
                        cc.log("Update finished.");
                        that._percent = 100;
                        that._progress.setPercentage(100);
                        that.unschedule(this.updateProgress);
                        that.scheduleOnce(that.loadGame,1.5);
                        break;
                    case jsb.EventAssetsManager.UPDATE_FAILED:
                        cc.log("Update failed. " + event.getMessage());
                        failCount++;
                        if (failCount < maxFailCount)
                        {
                            that._am.downloadFailedAssets();
                        }
                        else
                        {
                            cc.log("Reach maximum fail count, exit update process");
                            failCount = 0;
                            that.scheduleOnce(that.loadGame,1.5);
                        }
                        break;
                    case jsb.EventAssetsManager.ERROR_UPDATING:
                        cc.log("Asset update error: " + event.getAssetId() + ", " + event.getMessage());
                        that.scheduleOnce(that.loadGame,1.5);
                        break;
                    case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                        cc.log(event.getMessage());
                        that.scheduleOnce(that.loadGame,1.5);
                        break;
                    default:
                        break;
                }
            });
            cc.eventManager.addListener(listener, 1);
            cc.director.runScene(this);
        }
        this.scheduleOnce(this.startupdate,2);

    },
    startupdate : function () {
        this._am.update();
        this.schedule(this.updateProgress, 0.3);
    },
    loadGame:function(){
    //load jsList.js
        cc.loader.loadJs(JSLIST_PATH, function(){
            cc.loader.loadJs(jsList, function(){
                cc.director.runScene(new HelloWorldScene());
            });
        });
    },
    updateProgress:function(dt){
        //this._progress.string = "update" + this._percent + "%";
        this._progress.setPercentage(this._percent);
    },
    onExit:function(){
        cc.log("AssetsManager::onExit");
        this._am.release();
        this._super();
    }

});

AssetsManagerLoaderScene.runScene = function () {
    (new AssetsManagerLoaderScene()).run();
};
