/**
 * Created by Administrator on 2017/2/11.
 */
var jsList = [
    "src/app.js",
    "src/views/TP_Scroll/TP_Res.js",
    "src/views/TP_Scroll/TP_Scene.js",
    "src/views/UILayerLoading.js",
    "src/views/ExitTipsWnd.js",
    "src/views/GameStartScene.js",
    "src/tool/HttpTool.js",
    "src/tool/ipTools.js",
    "src/tool/FeedbackTips.js",
    "src/tool/NIK_Bridge.js",
    "src/tool/SDKListener.js"
];
