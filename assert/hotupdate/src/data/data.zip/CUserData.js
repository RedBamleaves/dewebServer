/**
 * Created by Administrator on 2017/2/8.
 */
//----------------------------------------------------------------------------
// @Copyright  : 2014-2015 Chenyu Investment
// @File       : CUserDataModel.h
// @Author     : samj
// @Email      :
// @Created    : 2014.2.18
// @Description: 游戏角色信息数据
//---------------------------------------------------------------------------

var CUserData = {
    loadUserDefault : function(){},	//加载本地默认信息
    saveUserDefault : function(){},
    //setUserBaseData(CMD_S_ROLE_INFO* pData);           //设置角色基础信息
    m_accid : 0,		        //账号Id
    m_account : '',		        //账号名
    m_rolename : '',		    //角色名
    m_password : '',		    //密码
    m_ticket : '',		        //登陆时间戳
    m_playerid : 0,		        //角色id
    m_faceid : 0,		        //头像
    m_roleid : 0,
    m_sex : 0,			        //性别
    m_level : 0,		        //等级
    m_gold : 0,			        //金币
    m_bgold : 0,		        //绑定金币
    m_coin : 0,			        //游戏币
    m_lchips : 0,		        //筹码
    m_tableid : 0,		        //桌子id
    m_chairid : 0,		        //椅子id
    m_iFirstCharge : 0,         //首充参数 0:表示还没有充过值   1:表示已经首充，但是尚未领取礼包   2:表示已经首充，并且已经领取了礼包
    //设置声音等信息
    m_bMusicOpen : true,        //声音是否打开
    m_bVoiceOpen : true,        //音效是否打开
    m_nMusicPercent : 50,        //  0 -100
    m_nVoicePercent : 50         // 0 -100
};

CUserData.loadUserDefault = function () {
    //read json file
};

CUserData.saveUserDefault = function () {
    //write json file
};



