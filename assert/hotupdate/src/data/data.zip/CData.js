/**
 * Created by Administrator on 2017/2/8.
 */

var CData = {
    m_online : 0,	//在线人数
    m_ip : '',
    m_port : 0,
    m_bMode : false,
    m_bSingen : false
};

