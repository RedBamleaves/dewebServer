/**
 * Created by Administrator on 2017/2/8.
 */

const MAX_RECONNECT =  5;
const ACCOUNT_PORT  = 5555;


var netRecon = {
    m_nReconnectNum : 0,
    m_bReconnect : false,
    m_nGameId : 0,
    m_nRoomId : 0,
    m_nTableId : 0
};

netRecon.sendLoginServer = function () {
    MsgTools.connectionServer(CData.m_ip,CData.m_port);
    let msg = MsgTools.create();
    msg.setOpcode(c2s_PROTOCOL.C2S_PLAYER_LOGON);
    let nAccountID = CUserData.m_accid;
    const pCharAccount = CUserData.m_account;
    const pCharTicket  = CUserData.m_ticket;
    msg.push_buffer_int(nAccountID,32)
        .push_buffer_constchar(pCharAccount)
        .push_buffer_constchar(pCharTicket)
        .SendSelf();
};

netRecon.sendReconnect = function () {
    const szAccount = CUserData.m_account;
    const szPwd     = CUserData.m_password;
    if(MsgTools.connectionServer(cocos_widget.SER_SOCK_URL, ACCOUNT_PORT))
    {
        netRecon.m_bReconnect = true;
        let msg = MsgTools.create();
        msg.setOpcode(c2s_PROTOCOL.C2S_ACCOUNT_LOGIN);
        let nVesion = 1; //nVesion
        msg.push_buffer_int(nVesion,32)
            .push_buffer_constchar(szAccount)
            .push_buffer_constchar(szPwd)
            .SendSelf();
    }

    netRecon.m_nReconnectNum += 1;
    if(netRecon.m_nReconnectNum > MAX_RECONNECT) {

    }
};

netRecon.responsePlayerLogin = function ()
{
    let msg = MsgTools.create();
    msg.setOpcode(c2s_PROTOCOL.C2S_REQ_PLAYER_ID);
    msg.SendSelf();
};

netRecon.responsePlayerId = function(nPlayerId) {
    let msg = MsgTools.create();
    msg.setOpcode(c2s_PROTOCOL.C2S_PLAYER_ENTER);
    msg.push_buffer_int(nPlayerId,32)
        .SendSelf();
};

netRecon.responsePlayerEnter = function(){
    let msg = MsgTools.create();
    msg.setOpcode(c2s_PROTOCOL.C2S_ROLE_INFO);
    msg.SendSelf();
};

netRecon.setReconnectSuccess = function() {
    netRecon.m_bReconnect = false;
    netRecon.m_nReconnectNum =0;
    switch(netRecon.m_nGameId)
    {
        case 3:
        {
            let nTableId = netRecon.m_nTableId;
            let msg = MsgTools.create();
            msg.setOpcode(c2s_PROTOCOL.C2S_DEPOKER_RECONNECT_JOIN);
            msg.push_buffer_int(nTableId,32)
                .SendSelf();
        }
            break;
        default:
            break;
    }
};

netRecon.setPlayGame = function(nGameId,nRoomId,nTableId)
{
    netRecon.m_nGameId = nGameId;
    netRecon.m_nRoomId = nRoomId;
    netRecon.m_nTableId = nTableId;
};
