/**
 * Created by Administrator on 2017/2/8.
 */
//游戏角色数据
var  CDzpkUserData = {
    nAccountId:0,
    strName:"",
    nFaceId:0,
    nGender:0,
    nLevel:0,
    nCareer:0,
    nTableId:0,
    nChairId:0,
    nCoin:0,
    nUserStatus:0,
    nGameGold:0,
    nExp:0,
    strWxUrl:""
};


//
var DzpkStartMsg = {
    nDelearCid :0,
    nSmallCid : 0,
    nBigCid : 0,
    nCurCid :0,
    nCellCoin :0,
    nAddLessCoin :0,
    nBalanceCoin:0,
    nTurnLessCoin:0,
    nTurnMaxCoin  :0,
    nHandCard:[0,0]
};

//
var DzpkFillMsg = {
    nFillCid:0,
    nNextCid :0,
    nFillCoin:0,
    nTurnLessCoin:0,
    nTurnMaxCoin:0,
    nAddLessCoin:0
};

var DzpkCenterCardMsg = {
    nBalance:0,
    nCurCid:0,
    nSendCardNum:0,
    nArrayCenterCard:[0,0,0,0,0]
};

var DzpkEndMsg = {
    nEndReason:0,
    mapEnd:null,
};

var DzpkEndInfo = {
    nCardType:0,
    nCoin:0,
    nArrayHandCard:[0,0],
    nArrayMaxCard:[0,0,0,0,0],
};

var DzpkEndPoolMsg = {
    mapPool:null,          //{pool, coin}
    mapChairList:null,    //{pool,[]}
};

