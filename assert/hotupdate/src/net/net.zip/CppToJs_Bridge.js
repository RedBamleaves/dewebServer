/**
 * Created by Administrator on 2017/2/9.
 */

function Reconnect() {
    netRecon.sendReconnect();
}

function AcceptMsgFromCpp(msg_id) {
    let msgtool = MsgTools.find(msg_id);
    if(msgtool !== null){
        let wMessageID = msgtool.getOpcode();
        if(typeof s2c_PROTOCOL['S2C_' + wMessageID] === 'function'){
            s2c_PROTOCOL['S2C_' + wMessageID](msgtool);
            msgtool.release();
        }
    }
}
