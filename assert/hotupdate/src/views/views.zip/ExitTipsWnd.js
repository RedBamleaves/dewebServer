/**
 * Created by Administrator on 2017/2/14.
 */

const  ExitTipsWnd_BKG = 'res/test/dezhoupukelioatian-dikuang.png';

const  ExitTipsWnd_CONFIRM_NORMAL = 'res/test/btn_game_history00.png';
const  ExitTipsWnd_CONFIRM_SELECTED = 'res/test/btn_game_history01.png';

const  ExitTipsWnd_CANCEL_NORMAL = 'res/test/btn_away00.png';
const  ExitTipsWnd_CANCEL_SELECTED = 'res/test/btn_away01.png';

var ExitTipsWnd = {};

ExitTipsWnd.Layer = cc.Layer.extend({
    tipStr : '确定退出页面?',
    confirm_btn : null,
    cancel_btn : null,
    confirm_cb : function () {},
    cancel_cb : function () {
        ExitTipsWnd.closeWnd();
    },

    onExit : function () {
        this._super();
        ExitTipsWnd.m_pSelf = null;
    },

    ctor : function (tips) {
        this._super();
        this.tipStr = tips;

        let bkg = new cc.Sprite(ExitTipsWnd_BKG);
        bkg.setAnchorPoint(cc.p(0.5,0.5));
        bkg.setPosition(cc.winSize.width/2,cc.winSize.height/2);
        this.addChild(bkg,1);

        let menu = cc.Menu.create();
        menu.setAnchorPoint(cc.p(0,0));
        menu.setPosition(cc.p(0,0));
        this.addChild(menu,2);

        this.confirm_btn = cc.MenuItemImage.create(ExitTipsWnd_CONFIRM_NORMAL,ExitTipsWnd_CONFIRM_SELECTED);
        this.confirm_btn.setAnchorPoint(cc.p(0.5,0.5));
        this.confirm_btn.setPosition(cc.winSize.width/2 - 100 , + cc.winSize.height/2 - 50);
        this.confirm_btn.setCallback(this.confirm_cb);
        menu.addChild(this.confirm_btn,1);

        this.cancel_btn = cc.MenuItemImage.create(ExitTipsWnd_CANCEL_NORMAL,ExitTipsWnd_CANCEL_SELECTED);
        this.cancel_btn.setAnchorPoint(cc.p(0.5,0.5));
        this.cancel_btn.setPosition(cc.winSize.width/2 + 100 , + cc.winSize.height/2 - 50);
        this.cancel_btn.setCallback(this.cancel_cb);
        menu.addChild(this.cancel_btn,1);

        let TipsLabel = new cc.LabelTTF(this.tipStr, "Arial", 38);
        TipsLabel.setAnchorPoint(cc.p(0.5,0.5));
        // position the label on the center of the screen
        TipsLabel.x = cc.winSize.width / 2;
        TipsLabel.y = cc.winSize.height / 2 + 50;
        // add the label as a child to this layer
        this.addChild(TipsLabel, 5);
    },

    setConfirm_cb : function (cb) {
        this.confirm_cb = cb;
        this.confirm_btn.setCallback(this.confirm_cb);
    },

    setCancel_cb : function (cb) {
        this.cancel_cb = cb;
        this.cancel_btn.setCallback(this.cancel_cb);
    }
});

ExitTipsWnd.m_pSelf = null;

ExitTipsWnd.openWnd = function (node,tips) {
    if(ExitTipsWnd.m_pSelf === null){
        ExitTipsWnd.m_pSelf = new ExitTipsWnd.Layer(tips);
        node.addChild(ExitTipsWnd.m_pSelf,20);
    }
    return ExitTipsWnd.m_pSelf;
};

ExitTipsWnd.closeWnd = function () {
    if(ExitTipsWnd.m_pSelf !== null){
        ExitTipsWnd.m_pSelf.removeAllChildren();
        ExitTipsWnd.m_pSelf.removeFromParent();
    }
    ExitTipsWnd.m_pSelf = null;
};