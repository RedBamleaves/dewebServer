/**
 * Created by Administrator on 2017/2/14.
 */

var GameStartScene = {};

GameStartScene.Scene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        GameStartScene.Layer.openWnd(this);
    }
});

GameStartScene.Layer = cc.Layer.extend({
    onExit : function () {
        this._super();
        GameStartScene.m_pSelf = null;
    },

    video_player : null,

    ctor : function () {
        this._super();
        ccui.VideoPlayer.EventType = {
            PLAYING: "play",
            PAUSED: "pause",
            STOPPED: "stop",
            COMPLETED: "complete"
        };

        this.video_player =  new ccui.VideoPlayer("res/test/videotest.mp4");
        this.video_player.setAnchorPoint(cc.p(0.5,0.5));
        this.video_player.setPosition(cc.p(cc.winSize.width/2,cc.winSize.height/2));
        this.video_player.setContentSize(cc.winSize);
        this.addChild(this.video_player);

        this.video_player.setEventListener(ccui.VideoPlayer.EventType.PLAYING, function(sender){
            cc.log("VideoPlayer PLAYING");
        });
        this.video_player.setEventListener(ccui.VideoPlayer.EventType.PAUSED, function(sender){
            cc.log("VideoPlayer PAUSED");
        });
        this.video_player.setEventListener(ccui.VideoPlayer.EventType.STOPPED, function(sender){
            cc.log("VideoPlayer STOPPED");
        });
        this.video_player.setEventListener(ccui.VideoPlayer.EventType.COMPLETED, function(sender){
            cc.log("VideoPlayer COMPLETED");//播放结束
            AssetsManagerLoaderScene.runScene();
        });

        if(this.video_player){
            this.video_player.setFileName("res/test/videotest.mp4");
            this.video_player.play();
        }
    }
});


GameStartScene.m_pSelf = null;

GameStartScene.openWnd = function (node) {
    if(GameStartScene.m_pSelf === null){
        GameStartScene.m_pSelf = new GameStartScene.Layer();
        node.addChild(GameStartScene.m_pSelf,99);
    }
    return GameStartScene.m_pSelf;
};

GameStartScene.runScene = function(){
    if(GameStartScene.m_pSelf === null){
        GameStartScene.m_pSelf = new GameStartScene.Layer();
        let scene = new cc.Scene();
        scene.addChild(GameStartScene.m_pSelf,99);
        cc.director.runScene(scene);
    }
    return GameStartScene.m_pSelf;
}

GameStartScene.closeWnd = function () {
    if(GameStartScene.m_pSelf !== null){
        GameStartScene.m_pSelf.removeAllChildren();
        GameStartScene.m_pSelf.removeFromParent();
    }
    GameStartScene.m_pSelf = null;
};
