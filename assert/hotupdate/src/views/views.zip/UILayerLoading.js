/**
 * Created by Administrator on 2017/2/14.
 */

var UILayerLoading = {};

UILayerLoading.Layer = cc.Layer.extend({

    onExit : function () {
        this._super();
        UILayerLoading.m_pSelf = null;
    },

    ctor : function () {
        this._super();
        let sp_01 = new cc.Sprite("res/test/loading_00.png");
        sp_01.setPosition(cc.p(cc.winSize.width/2,cc.winSize.height/2));
        this.addChild(sp_01);

        let sp_02 = new cc.Sprite("res/test/loading_01.png");
        sp_02.setPosition(cc.p(cc.winSize.width/2,cc.winSize.height/2));
        this.addChild(sp_02);

        let rote = cc.rotateBy(2,360);
        sp_02.runAction(cc.repeatForever(rote));

        let listener = cc.EventListener.create({
            event:cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan:function(touch,event){
                return true;
            }
        });
        cc.eventManager.addListener(listener,this);
    }
});

UILayerLoading.m_pSelf = null;

UILayerLoading.openWnd = function (node) {
    if(UILayerLoading.m_pSelf === null){
        UILayerLoading.m_pSelf = new UILayerLoading.Layer();
        node.addChild(UILayerLoading.m_pSelf,999);
    }
    return UILayerLoading.m_pSelf;
};

UILayerLoading.closeWnd = function () {
    if(UILayerLoading.m_pSelf !== null){
        UILayerLoading.m_pSelf.removeAllChildren();
        UILayerLoading.m_pSelf.removeFromParent();
    }
    UILayerLoading.m_pSelf = null;
};