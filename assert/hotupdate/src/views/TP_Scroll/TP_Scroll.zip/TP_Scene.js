/**
 * Created by Administrator on 2017/2/13.
 */

var TP_Scroll = {};

TP_Scroll.TP_Scene = cc.Scene.extend({
    onEnter : function () {
        this._super();
    },

    ctor : function (tpTo) {
        this._super();
        let layer = new TP_Scroll.TP_Layer(tpTo);
        this.addChild(layer);
    }
});

TP_Scroll.TP_Layer = cc.Layer.extend({
    progress : null,
    prog_lab : null,
    progress_dian : null,
    strTextrue : '',
    strPlist : '',
    m_nCurrentNum : 0,                      //当前加载完成第几张
    m_nTotalNum : 0,                        //需要加载总数
    res_count : 0,                          //当前加载到第几张
    m_pngToplist : 0,                       //png－plist总数
    m_pvrToplist : 0,                       //pvr－plist总数
    m_png : 0,                              //png总数
    go_address : Tp_Address.TP_None,        //目标地
    go_hear : Tp_Address.TP_None,           //目前所在地

    ctor : function (tpTo) {
        this._super();
        this.go_address = tpTo;
        if(this.go_address !== Tp_Address.TP_None){
            this.visibleSize = cc.director.getVisibleSize();
            this.res_count = 0;
            this.m_nCurrentNum = 0;

            this.m_pngToplist = TP_Res[Tp_Address.TP_Depoker].png_sheet.length;
            this.m_pvrToplist = TP_Res[this.go_address].pvr_sheet.length;
            this.m_png        = TP_Res[this.go_address].scat.length;
            this.m_nTotalNum  = this.m_pngToplist + this.m_pvrToplist + this.m_png;
            this.InitUI();
            this.Teleport_To();
        }
    },

    Teleport_To : function(){
        this.release_Cache();    //释放旧资源
        this.scheduleUpdate();   //加载新资源
    },

    InitUI : function () {
        let labtips = new cc.LabelTTF(randChoice(Tp_Tips), "Arial", 22);
        labtips.setPosition(cc.p(1136/2 ,50));
        labtips.setAnchorPoint(cc.p(0.5,0.5));
        labtips.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        labtips.setColor(cc.color(178,173,219));
        this.addChild(labtips,3);

        let pSpritebkg = new cc.Sprite("res/tpTest/guochang_bg.png");
        pSpritebkg.setPosition(cc.p(this.visibleSize.width/2, this.visibleSize.height/2));
        this.addChild(pSpritebkg ,1);

        let pLogo = new cc.Sprite("res/tpTest/guochang_logo.png");
        pLogo.setPosition(cc.p(568,400));
        pSpritebkg.addChild(pLogo);

        let progress_di = new cc.Sprite("res/tpTest/guochang_progress_di.png");
        progress_di.setPosition(cc.p(this.visibleSize.width/2, 140));
        this.addChild(progress_di ,2);

        this.progress = new cc.ProgressTimer(new cc.Sprite("res/tpTest/guochang_progress_tiao.png"));
        this.progress.setAnchorPoint(cc.p(0.5,0.5));
        this.progress.setPosition(cc.p(progress_di.getContentSize().width/2,progress_di.getContentSize().height/2));
        this.progress.setType(cc.ProgressTimer.TYPE_BAR);
        this.progress.setMidpoint(cc.p(0,0));
        this.progress.setBarChangeRate(cc.p(1, 0));
        progress_di.addChild(this.progress,1);
        this.progress.setPercentage(0);

        let progress_guang = new cc.Sprite("res/tpTest/guochang_progress_guang.png");
        progress_guang.setAnchorPoint(cc.p(0.5,0.5));
        progress_guang.setPosition(cc.p(progress_di.getContentSize().width/2, progress_di.getContentSize().height/2));
        progress_di.addChild(progress_guang ,2);

        this.progress_dian = new cc.Sprite("res/tpTest/guochang_progress_dian.png");
        this.progress_dian.setAnchorPoint(cc.p(0.5,0.5));
        this.progress_dian.setPosition(cc.p(8, progress_di.getContentSize().height/2+2));
        progress_di.addChild(this.progress_dian ,3);

        this.prog_lab = new cc.LabelTTF("0","Arial",24);
        this.prog_lab.setAnchorPoint(cc.p(0.5,0.5));
        this.prog_lab.setColor(cc.color(255,255,255));
        this.prog_lab.setPosition(this.visibleSize.width/2,200);
        this.addChild(this.prog_lab,2);

        // ccs.ArmatureDataManager.getInstance().addArmatureFileInfo("res/tpTest/guochang_effect.ExportJson");
        // let armature = new ccs.Armature("res/tpTest/guochang_effect");
        // armature.setPosition(cc.p(558,265));
        // armature.getAnimation().playWithIndex(0);
        // this.addChild(armature ,5);
    },

    update : function(){
        if(this.m_nTotalNum === 0)
        {
            this.progress.setPercentage(100);
            this.progress_dian.setPosition(cc.p(270 - 8,this.progress.getContentSize().height/2+2));
            this.progress_dian.setOpacity(0);

            let str = "100%";
            this.prog_lab.setString(str);
            this.scheduleOnce(this.updateOnce ,0.5);
            return;
        }

        let str = "";
        if(this.res_count >= 0 && this.res_count < this.m_png)
        {
            this.strTextrue = TP_Res[this.go_address].scat[this.res_count];
            str = this.strTextrue + ".png";
        }
        else if(this.res_count >= this.m_png && this.res_count < this.m_pngToplist + this.m_png)
        {
            this.strTextrue = TP_Res[this.go_address].png_sheet[this.res_count - this.m_png];
            str = this.strTextrue + ".png";
        }
        else if(this.res_count >= this.m_pngToplist + this.m_png && this.res_count < this.m_nTotalNum)
        {
            this.strTextrue = TP_Res[this.go_address].pvr_sheet[this.res_count - this.m_png - this.m_pngToplist];
            str = this.strTextrue + ".pvr.ccz";
        }
        cc.textureCache.addImageAsync(str, this.imageAsyncCallback, this);
        ++this.res_count;
        if(this.res_count === this.m_nTotalNum)
        {
            this.unscheduleUpdate();
        }
    },

    imageAsyncCallback : function(texture){
        if(this.m_nCurrentNum >= this.m_png)
        {
            let _str = "";
            if(this.m_nCurrentNum >= this.m_png && this.m_nCurrentNum < this.m_pngToplist + this.m_png)
            {
                _str = TP_Res[this.go_address].png_sheet[this.m_nCurrentNum - this.m_png];
            }
            else if(this.m_nCurrentNum >= this.m_pngToplist + this.m_png && this.m_nCurrentNum < this.m_nTotalNum)
            {
                _str = TP_Res[this.go_address].pvr_sheet[this.m_nCurrentNum - this.m_png - this.m_pngToplist];
            }
            _str += ".plist";
            cc.spriteFrameCache.addSpriteFrames(_str, texture);
        }

        //currentNum初始值为0，每加载一张纹理值自加1
        ++this.m_nCurrentNum;
        //求得百分比
        let per_int = parseInt(this.m_nCurrentNum / this.m_nTotalNum * 100);
        //设置标签显示的内容
        this.prog_lab.setString(per_int + '%');

        if(per_int >= 4.0 && per_int <= 96.0)
        {
            let to_p = cc.p(270 * this.m_nCurrentNum / this.m_nTotalNum, this.progress.getContentSize().height/2 + 2);
            this.progress_dian.setPosition(to_p);
            // this.progress_dian.stopAllActions();
            // this.progress_dian.runAction(cc.moveTo(0.8,to_p));
            if( per_int >= 80.0 && this.progress_dian.getOpacity() >= 64 ){
                this.progress_dian.setOpacity(this.progress_dian.getOpacity() - 64);
            }
        }

        this.progress.setPercentage(per_int);
        // this.progress.stopAllActions();
        // this.progress.runAction(cc.progressTo(0.8,per_int));
        //如果当前加载的张数跟总数相等则进行场景跳转
        if(this.m_nCurrentNum === this.m_nTotalNum)
        {
            this.progress.setPercentage(100);
            // this.progress.stopAllActions();
            // this.progress.runAction(cc.progressTo(0.8,100));

            let to_p = cc.p(270 * this.m_nCurrentNum / this.m_nTotalNum, this.progress.getContentSize().height/2 + 2);
            this.progress_dian.setPosition(to_p);
            this.progress_dian.setPosition(cc.p(270 * this.m_nCurrentNum / this.m_nTotalNum - 8,
                this.progress.getContentSize().height/2 + 2));
            this.progress_dian.setOpacity(0);
            str = "100%";
            this.prog_lab.setString(str);
            this.scheduleOnce(this.updateOnce, 0.5);
            //jump_ScenLayer();0
        }
    },

    release_Cache : function(){
        cc.audioEngine.stopAllEffects();
        //这个之后需要解开
        // if(UILayerLoading::getSelf())
        // {
        //     UILayerLoading::getSelf()->closeWindow();
        // }

        cc.textureCache.removeAllTextures();//释放不用的纹理缓存
        if(this.go_hear === Tp_Address.TP_None)
        {
            return;
        }

        let n_pngToplist    = TP_Res[this.go_hear].png_sheet.length;
        let n_pvrToplist    = TP_Res[this.go_hear].pvr_sheet.length;

        for(let i = 0;i < n_pngToplist;++i)
        {
            let plistName = TP_Res[this.go_hear].png_sheet[i];
            cc.spriteFrameCache.removeSpriteFramesFromFile(plistName + ".plist");//释放不用的PngFrame缓存
        }

        for(let j = 0;j<n_pvrToplist;++j)
        {
            let plistName = TP_Res[this.go_hear].pvr_sheet[j];
            cc.spriteFrameCache.removeSpriteFramesFromFile(plistName + ".plist");//释放不用的PvrFrame缓存
        }
    },

    updateOnce : function(){
        this.release_Texture();//释放多余的纹理
        this.jump_ScenLayer();
    },

    jump_ScenLayer : function() {
        this.addChild(new cc.Sprite('#notice_CFDXCZCX_06.png'),999);

        return;
        this.removeAllChildren();
        this.removeFromParent();

        switch (this.go_hear) {
            case Tp_Address.TP_Depoker:
                netRecon.setPlayGame(0, 0, 0);
                break;
            default:
                break;
        }

        switch (this.go_address) {
            case Tp_Address.TP_Depoker:
                //这里执行进入德州的内容
                break;
            default:
                break;
        }

        this.go_hear = this.go_address;
        this.go_address = TP_Res.TP_None;

        setTimeout(function () {
            TP_Scroll.func();
            TP_Scroll.func = function () {};
        }, 0.2 * 1000);
    },

    release_Texture : function(){
        let n_pngToplist    = TP_Res[this.go_address].png_sheet.length;
        let n_pvrToplist    = TP_Res[this.go_address].pvr_sheet.length;

        for(let i = 0;i<n_pngToplist;++i)
        {
            let plistName = TP_Res[this.go_address].png_sheet[i];
            cc.textureCache.removeTextureForKey(plistName + ".png");//释放不用的Png纹理缓存
        }

        for(let j = 0;j<n_pvrToplist;++j)
        {
            let plistName = TP_Res[this.go_address].pvr_sheet[j];
            cc.textureCache.removeTextureForKey(plistName + ".pvr.ccz");//释放不用的Pvr纹理缓存
        }
    }
});

TP_Scroll.func = function () {};    //这个函数独立出来定义，在加载完成跳转后0.2s后进行调用

TP_Scroll.FlyTo = function (tpTo) {
    cc.director.runScene(new TP_Scroll.TP_Scene(tpTo));
};
