/**
 * Created by Administrator on 2017/2/13.
 */

var Tp_Tips = [
    "小技巧：德州扑克中，要小心对方下的钓饵。",
    "小技巧：德州扑克中，拿到烂牌后视情况跟注看前三张河牌，说不定能起死回生。",
    "小提示：强大的心里素质能够战胜一切。",
    "小提示：不要因一时的失败降低自己气势，保持旺盛的斗志才能反败为胜。"
];

var Tp_Address = {
    TP_None : 'TP_None',
    TP_mainScene : 'TP_mainScene',
    TP_Depoker   : 'TP_Depoker'
};

var TP_Res = {
    TP_mainScene : {
        png_sheet :[],
        pvr_sheet :[],
        scat :[]
    },
    TP_Depoker : {
        png_sheet :[
            // 'res/dzpk/card',
            // 'res/dzpk/head'
        ],
        pvr_sheet :[
              'res/dzpk/dezhouDH',
              'res/dzpk/dezhouSL',
              'res/dzpk/FormPL',
              'res/dzpk/mainbar',
              'res/test/top_menu',
              'res/test/testjiami'
        ],
        scat :[
            // 'res/testTest/ShaiBao_Bkg@2x',
            // 'res/testTest/UiBetMain',
            // 'res/testTest/UILunOanBetBg',
            // 'res/testTest/UiLunPanBetBg'
        ]

    }
};
