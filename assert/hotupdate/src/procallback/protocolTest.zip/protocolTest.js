/**
 * Created by Administrator on 2017/2/9.
 */

s2c_PROTOCOL.S2C_22222 = function (msgtool) {
    cc.log("AcceptMsgFromCpp! " + msgtool.getOpcode());
};

s2c_PROTOCOL.S2C_60001 = function (msgtool) {
    let dddddd = msgtool.pop_buffer_int(8);
    let nAccountID  = msgtool.pop_buffer_int(32);
    let strAccount  = msgtool.pop_buffer_constchar();
    let strTicket   = msgtool.pop_buffer_constchar();

    log('nAccountID : ' + nAccountID);
    log('strAccount : ' + strAccount);
    log('strTicket : ' + strTicket);
};