/**
 * Created by Administrator on 2017/2/9.
 */
//depoker protocl

s2c_PROTOCOL.S2C_13001 = function (Msgtool) {
    cc.log("AcceptMsgFromCpp! " + Msgtool.getOpcode());
    let nUserID = Msgtool.pop_buffer_int(32);
    let strRoleName = Msgtool.pop_buffer_constchar();

    let cbLevel = Msgtool.pop_buffer_int(8);
    let nExp = Msgtool.pop_buffer_int(32);
    let nMaxExp = Msgtool.pop_buffer_int(32);

    let cbSex = Msgtool.pop_buffer_int(8);
    let cbProfession = Msgtool.pop_buffer_int(8);
    let cbCamp = Msgtool.pop_buffer_int(8);
    let cbLivePlace = Msgtool.pop_buffer_int(8);
    let cbHeadImg = Msgtool.pop_buffer_int(8);
    let cbResourceID = Msgtool.pop_buffer_int(8);

    let nGoldNum = Msgtool.pop_buffer_int(32);
    let nSilverNum = Msgtool.pop_buffer_int(32);
    let nCopperNum = Msgtool.pop_buffer_int(64);
    let nJettons = Msgtool.pop_buffer_int(32);
    let nPhysicalPower = Msgtool.pop_buffer_int(32);
    let nMaxPhysicalPower = Msgtool.pop_buffer_int(32);
    let nCharm = Msgtool.pop_buffer_int(32);
    let nMaxCharm = Msgtool.pop_buffer_int(32);
    let nFortuneValue = Msgtool.pop_buffer_int(32);
    let nActive = Msgtool.pop_buffer_int(16);
    let nMapID = Msgtool.pop_buffer_int(32);

    let wPosX = Msgtool.pop_buffer_int(16);
    let wPosY = Msgtool.pop_buffer_int(16);
    let wRideID = Msgtool.pop_buffer_int(16);

    let bVipLevel = Msgtool.pop_buffer_int(8);
    let nVipTime = Msgtool.pop_buffer_int(32);
    let wTitleID = Msgtool.pop_buffer_int(16);

    let strTitleName = Msgtool.pop_buffer_constchar();
    let nClubID = Msgtool.pop_buffer_int(32);
    let strClubName = Msgtool.pop_buffer_constchar();
    let cbClubPost = Msgtool.pop_buffer_int(8);

    let wFortuneRank = Msgtool.pop_buffer_int(16);
    let wFortuneDayRank = Msgtool.pop_buffer_int(16);

};

s2c_PROTOCOL.S2C_13005 = function (Msgtool) {
    let cbType = Msgtool.pop_buffer_int(8);
}

s2c_PROTOCOL.S2C_13011 = function (Msgtool) {
    let nPlayerID = Msgtool.pop_buffer_int(32);
    let nGold = Msgtool.pop_buffer_int(32);
    let nBgold = Msgtool.pop_buffer_int(32);
    let nCoin = Msgtool.pop_buffer_int(64);
    let nJettons = Msgtool.pop_buffer_int(32);
    let nLoveliness = Msgtool.pop_buffer_int(32);
    let nFortune = Msgtool.pop_buffer_int(32);
    let wActives = Msgtool.pop_buffer_int(16);
}

s2c_PROTOCOL.S2C_13020 = function (Msgtool) {
    let cbRet = Msgtool.pop_buffer_int(8);
}

s2c_PROTOCOL.S2C_13021 = function (Msgtool) {
    let cbRet = Msgtool.pop_buffer_int(8);
    let nCoins = Msgtool.pop_buffer_int(32);
    let nIntegral = Msgtool.pop_buffer_int(32);
}

s2c_PROTOCOL.S2C_13022 = function (Msgtool) {
    let cbRet = Msgtool.pop_buffer_int(8);
}

s2c_PROTOCOL.S2C_13023 = function (Msgtool) {
    let wNum = Msgtool.pop_buffer_int(16);
}


/*
s2c_PROTOCOL.S2C_60001 = function (msgtool) {
    let dddddd = msgtool.pop_buffer_int(8);
    let nAccountID  = msgtool.pop_buffer_int(32);
    let strAccount  = msgtool.pop_buffer_constchar();
    let strTicket   = msgtool.pop_buffer_constchar();

    log('nAccountID : ' + nAccountID);
    log('strAccount : ' + strAccount);
    log('strTicket : ' + strTicket);
};
*/