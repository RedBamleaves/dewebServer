/**
 * Created by Administrator on 2017/2/9.
 */
//S2C_PLAYER_LOGON	   =10000,
s2c_PROTOCOL.S2C_10000 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);
    if(netRecon.m_bReconnect) {
        netRecon.responsePlayerLogin();
    }
    else {
        //CCoreShell::getInstance()->CoreDataChange(GDCNI_PLAYER_LOGIN, 0, cRet);
    }
};

//S2C_PLAYER_LOGOUT  = 10001,     //退出登录
s2c_PROTOCOL.S2C_10001 = function (MsgTool) {

};

// S2C_REQ_PLAYER_ID   = 10002,     //请求角色ID
s2c_PROTOCOL.S2C_10002 = function (MsgTool) {
    let nPlayerId  = MsgTool.pop_buffer_int(32);
    if(netRecon.m_bReconnect) {
        netRecon.responsePlayerId(nPlayerId);
    }
    else {
       // CCoreShell::getInstance()->CoreDataChange(GDCNI_REQ_PLAYER_ID, 0, nPlayerID);
    }
};

// S2C_PLAYER_CREAT	= 10003,
s2c_PROTOCOL.S2C_10003 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);;
    //	CCoreShell::getInstance()->CoreDataChange(GDCNI_PLAYER_CREAT, 0, cbRet);
};
// S2C_PLAYER_ENTER   = 10004,     //请求角色ID
s2c_PROTOCOL.S2C_10004 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);
    if(netRecon.m_bReconnect) {
        netRecon.responsePlayerEnter();
    }
    else {
      // CCoreShell::getInstance()->CoreDataChange(GDCNI_PLAYER_ENTER, 0, cRet);
    }
};

// S2C_PLAYER_DEL	= 10005,   //删除角色
s2c_PROTOCOL.S2C_10005 = function (MsgTool) {

};
// S2C_PLAYER_LOGINED	= 10007, 账号在别处已登录
s2c_PROTOCOL.S2C_10007 = function (MsgTool) {
};
// S2C_CHECK_ROLE_NAME   = 10010     //检查名字是否重复
s2c_PROTOCOL.S2C_10010 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);
   /*
    UILoginSelRole* pUiWnd = UILoginSelRole::getSelf();
    if( pUiWnd)
    {
    pUiWnd->responseIsNameHad(cbRet);
    }
    */
};