/**
 * Created by Administrator on 2017/2/9.
 */

//S2C_ACCOUNT_SERVER  = 60000
s2c_PROTOCOL.S2C_60000 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);
    if(cRet === 0) {
        let nPort = MsgTool.pop_buffer_int(16);
        let nOnlineNum = MsgTool.pop_buffer_int(16);
        let strIp = MsgTool.pop_buffer_constchar();

        //保存服务器信息，登录服务器
        CData.m_ip = "www.dayingjiaol.com";//"123.57.31.71";
        CData.m_port = nPort;
        CData.m_online = nOnlineNum;

        if(netRecon.m_bReconnect) {
            netRecon.sendLoginServer();
        }
        else {
            //CCoreShell::getInstance()->CoreDataChange(GDCNI_ACCOUNT_SERVER, 0, cRet);
        }
    }
};

// S2C_ACCOUNT_LOGIN = 60001
s2c_PROTOCOL.S2C_60001 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);;
    if(cRet === 0) {
        let nAccountID = MsgTool.pop_buffer_int(32);
        let strAccount = MsgTool.pop_buffer_constchar();
        let strTicket = MsgTool.pop_buffer_constchar();

        CUserData.m_accid = nAccountID;
        CUserData.m_account = strAccount;
        CUserData.m_ticket = strTicket;
        CUserData.saveUserDefault();
    }

    if(!netRecon.m_bReconnect) {
        //通知界面数据到达
        //CCoreShell::getInstance()->CoreDataChange(GDCNI_ACCOUNT_LOGIN, 0, cRet);
    }
};
// S2C_ACCOUNT_REGISTER	= 60002,
s2c_PROTOCOL.S2C_60002 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);;
    if(cRet === 0) {
        let nAccountID = MsgTool.pop_buffer_int(32);
        let strAccount = MsgTool.pop_buffer_constchar();
        let strPwd     = MsgTool.pop_buffer_constchar();
        let strTicket  = MsgTool.pop_buffer_constchar();

        CUserData.m_accid = nAccountID;
        CUserData.m_account = strAccount;
        CUserData.m_password = strPwd;
        CUserData.m_ticket = strTicket;
        CUserData.saveUserDefault();
    }
    //CCoreShell::getInstance()->CoreDataChange(GDCNI_ACCOUNT_REGIST, 0, cRet);
};

// S2C_ACCOUNT_GUEST = 60003,
s2c_PROTOCOL.S2C_60003 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);
    if(cRet === 0) {
        let nAccountID = MsgTool.pop_buffer_int(32);
        let strAccount = MsgTool.pop_buffer_constchar();
        let strPwd     = MsgTool.pop_buffer_constchar();
        let strTicket  = MsgTool.pop_buffer_constchar();

        CUserData.m_accid = nAccountID;
        CUserData.m_account = strAccount;
        CUserData.m_password = strPwd;
        CUserData.m_ticket = strTicket;
        CUserData.saveUserDefault();
    }
    //通知界面数据到达
    //CCoreShell::getInstance()->CoreDataChange(GDCNI_ACCOUNT_GUEST, 0, cRet);
};

//S2C_ACCOUNT_AMEND_PWD = 60004
s2c_PROTOCOL.S2C_60004 = function (MsgTool) {
    let cRet = MsgTool.pop_buffer_int(8);
    /*
    if(UILogin_forPassword::getSelf())
    {
        UILogin_forPassword::getSelf()->responseOK(cRet);
    }*/
};
