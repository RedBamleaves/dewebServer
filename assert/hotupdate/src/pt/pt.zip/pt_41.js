/**
 * Created by Administrator on 2017/2/9.
 */
//depoker protocl
/*
 C2S_TABLE_GAME_ENTER       :41000,    //进入游戏
 C2S_TABLE_GAME_JOIN		  :41001,	//加入
 S2C_TABLE_GAME_LEAVE       :41002,	//离开
 S2C_TABLE_GAME_START	      :41003,	//开始
 S2C_TABLE_GAME_ABANDON	  :41004,	//放弃
 S2C_TABLE_GAME_FILLED	  :41005,	//加注
 S2C_TABLE_GAME_OPENED	  :41006,	//开牌
 S2C_TABLE_GAME_STANDUP    :41007,	//站起
 S2C_TABLE_GAME_SITDOWN	  :41008,	//坐下
 S2C_TABLE_CHANGE           :41009,    //换桌
 S2C_TABLE_FEE              :41010,    //小费
 S2C_TABLE_USE_MAGIC       :41015,    //使用魔法道具
 S2C_TABLE_GAME_MEMBER     :41020,    //将自己信息发送给其它桌子上的玩家，
 S2C_TABLE_GAME_MBLIST	 :41021,	//发送玩家信息列表给自己
 S2C_TABLE_GAME_TIMER	     :41022,	//发送时间
 S2C_TABLE_GAME_CARD		 :41023,	//发送下一把牌
 S2C_TABLE_POOL_LIST       :41024,    //边池
 S2C_TABLE_SYNC_TAKE_SCORE :41025,    //同步筹码

 S2C_TABLE_SHOW_MY_HAND_CARD :41027,  //客户端玩家发送亮牌
 S2C_TABLE_HAND_CARD          :41028,    //玩家手中的牌
 S2C_TABLE_END                 :41029,    //结束时候发送
 S2C_POOL_LIST_END            :41030,     //结束
 C2S_DEPOKER_RECONNECT_JOIN : 41060     //从新加入
 */

//
s2c_PROTOCOL.S2C_41000 = function (MsgTool) {
    let nRet =  MsgTool.pop_buffer_int(8);
    g_DepokerData.responseCheckEnter(nRet);
    cc.log("AcceptMsgFromCpp! " + MsgTool.getOpcode());
};

//S2C_TABLE_GAME_LEAVE = 41002,	//离开
s2c_PROTOCOL.S2C_41001 = function (MsgTool) {
    let nCid =  MsgTool.pop_buffer_int(8);
    g_DepokerData.responseUserLeave(nCid);
    //
    cc.log("ProcessPlayerLeave !");

/*
    msg >> cbChairId;
    CData::getCData()->m_dictionary->removeObjectForKey(cbChairId);
    CCoreShell::getInstance()->CoreDataChange(GDCNI_TABLE_USER_LEAVE, 0, cbChairId);
    cc.log("S2C_41001! " + MsgTool.getOpcode());
    */
};

s2c_PROTOCOL.S2C_41002 = function (MsgTool) {
    cc.log("AcceptMsgFromCpp! " + MsgTool.getOpcode());
};
//start
s2c_PROTOCOL.S2C_41003 = function (MsgTool) {
    let data  = new DzpkStartMsg;
    data.nDelearCid    =  MsgTool.pop_buffer_int(8);
    data.nSmallCid     =  MsgTool.pop_buffer_int(8);
    data.nBigCid       =  MsgTool.pop_buffer_int(8);
    data.nCurCid        =  MsgTool.pop_buffer_int(8);
    data.nCellCoin     =  MsgTool.pop_buffer_int(32);
    data.nAddLessCoin  =  MsgTool.pop_buffer_int(32);
    data.nBalanceCoin  =  MsgTool.pop_buffer_int(32);
    data.nTurnLessCoin =  MsgTool.pop_buffer_int(32);
    data.nTurnMaxCoin  =  MsgTool.pop_buffer_int(32);
    let nCardCount = MsgTool.pop_buffer_int(16);
    for(let i = 0; i < 2; i ++) {
        let nCard = MsgTool.pop_buffer_int(8);
        data.nHandCard[i] = nCard;
    }
    g_DepokerData.responseStart(data);
    cc.log("S2C_41003 GameStart!");
};

//S2C_TABLE_GAME_ABANDON = 41004,	//放弃
s2c_PROTOCOL.S2C_41004 = function (MsgTool) {
    let nCid =  MsgTool.pop_buffer_int(8);
    //输掉的筹码
    let nLostCoin = MsgTool.pop_buffer_int(32);
    g_DepokerData.responseDiscard(nCid, nLostCoin);
    cc.log("Discard Cid=! " + nCid );
};

//S2C_TABLE_GAME_FILLED	  :41005,	//加注
s2c_PROTOCOL.S2C_41005 = function (MsgTool) {
    var data = new DzpkFillMsg;
    data.nFillCid = MsgTool.pop_buffer_int(8);
    data.nFillCoin = MsgTool.pop_buffer_int(32);
    data.nNextCid  = MsgTool.pop_buffer_int(8);
    data.nTurnLessCoin =  MsgTool.pop_buffer_int(32);
    data.nTurnMaxCoin   =  MsgTool.pop_buffer_int(32);
    data.nAddLessCoin  =  MsgTool.pop_buffer_int(32);
    g_DepokerData.responseAddCoin(data);
    cc.log("S2C_41005 AddCoin is OK !!! " );
};

s2c_PROTOCOL.S2C_41006 = function (MsgTool) {
    cc.log("AcceptMsgFromCpp Add Coin ! " + MsgTool.getOpcode());
};

s2c_PROTOCOL.S2C_41007 = function (MsgTool) {
    cc.log("AcceptMsgFromCpp! " + MsgTool.getOpcode());
};
s2c_PROTOCOL.S2C_41008 = function (MsgTool) {
    cc.log("AcceptMsgFromCpp! " + MsgTool.getOpcode());
};

s2c_PROTOCOL.S2C_41009 = function (MsgTool) {
    cc.log("AcceptMsgFromCpp! " + MsgTool.getOpcode());
};

//S2C_TABLE_FEE = 41010,    //小费
s2c_PROTOCOL.S2C_41010 = function (MsgTool) {
    let  nCid = MsgTool.pop_buffer_int(8);
    /*
    UIGameClentView* pUiWnd = UIGameClientView::getSelf();
    if( pUiWnd )
    {
        pUiWnd->daShangArrive(cbChairID);
    }
    cc.log("AcceptMsgFromCpp! " + MsgTool.getOpcode());
    */
};

//S2C_TABLE_USE_MAGIC   = 41015,    //使用魔法道具
s2c_PROTOCOL.S2C_41015 = function (MsgTool) {
    let  nMagicId = MsgTool.pop_buffer_int(8);
    let  nFromCid = MsgTool.pop_buffer_int(8);
    let  nToCid  = MsgTool.pop_buffer_int(8);
    /*
    auto pUiWind = UIGameClientView::getSelf();
    if(pUiWind)
    {
        pUiWind->responseUseMagic(cbMagicId, cbFrom, cbTo);
    }
    */
};

// S2C_TABLE_GAME_MEMBER     :41020,    //将自己信息发送给其它桌子上的玩家，
s2c_PROTOCOL.S2C_41020 = function (MsgTool) {
    let nCount = MsgTool.pop_buffer_int(16);
    for(let  i = 0; i < nCount; i++) {
        let  data  = new CDzpkUserData;
        data.nChairId = MsgTool.pop_buffer_int(8);
        data.nAccountId = MsgTool.pop_buffer_int(32);
        data.nFaceId = MsgTool.pop_buffer_int(16);
        data.nLevel = MsgTool.pop_buffer_int(8);
        data.nCareer = MsgTool.pop_buffer_int(8);
        data.nGender = MsgTool.pop_buffer_int(8);
        data.nCoin = MsgTool.pop_buffer_int(32);
        data.nUserStatus = MsgTool.pop_buffer_int(8);
        data.strName = MsgTool.pop_buffer_constchar();
        data.strWxUrl = MsgTool.pop_buffer_constchar();
        //
        g_DepokerData.responseUserEnter(data);
    }
};
//S2C_TABLE_GAME_CARD = 41023;
s2c_PROTOCOL.S2C_41023 = function (MsgTool) {
    let  data = new DzpkCenterCardMsg;
    data.nBalance  =  MsgTool.pop_buffer_int(8);
    data.nCurCid   =  MsgTool.pop_buffer_int(8);
    data.nCardNum  =  MsgTool.pop_buffer_int(16);
    for(let i = 0; i <　data.nCardNum; i ++){
        data.nArrayCenterCard[i] = MsgTool.pop_buffer_int(8);
    }
    g_DepokerData.responseCenterCard(data);
};

//S2C_TABLE_POOL_LIST  = 41024
s2c_PROTOCOL.S2C_41024 = function (MsgTool) {
    let data = new Map();
    let nNum = MsgTool.pop_buffer_int(16);
    for (let i = 0; i < nNum; i++) {
        let nKey =  MsgTool.pop_buffer_int(8);
        let nCoin =  MsgTool.pop_buffer_int(32);
        data.set(nKey, nCoin);
    }
    g_DepokerData.updatePool(data);
};

//S2C_TABLE_SYNC_TAKE_SCORE  = 41025
s2c_PROTOCOL.S2C_41025 = function (MsgTool) {
    let data = new Map();
    let nNum = MsgTool.pop_buffer_int(16);
    for (let i = 0; i < nNum; i++) {
        let nCid =  MsgTool.pop_buffer_int(8);
        let nCoin =  MsgTool.pop_buffer_int(32);
        data.set(nCid, nCoin);
    }
    g_DepokerData.updateTakeCoin(data);
};

//S2C_TABLE_SHOW_MY_HAND_CARD  = 41027
s2c_PROTOCOL.S2C_41027 = function (MsgTool) {

};
 //S2C_TABLE_HAND_CARD   = 41028,    //玩家手中的牌
 s2c_PROTOCOL.S2C_41028 = function (MsgTool) {
     let nNum = MsgTool.pop_buffer_int(16);
     for(let i = 0; i < nNum; i++) {
         let nCid     =  MsgTool.pop_buffer_int(8);
         let nCardNum =  MsgTool.pop_buffer_int(16);
         let nArrayHandCard = [0,0];
         for(let  j = 0; j < nCardNum; j++) {
             nArrayHandCard[j] = MsgTool.pop_buffer_int(8);
         }
         let pUiWnd =  UiDepokerView.getSelf();
         if( pUiWnd) {
             pUiWnd.setGameALLINCard(nCid, nArrayHandCard[0], nArrayHandCard[1]);
         }
     }
 };

 //S2C_TABLE_END = 41029,    //结束时候发送
s2c_PROTOCOL.S2C_41029 = function (MsgTool) {
    let data = new DzpkEndMsg;
    data.nEndReason = MsgTool.pop_buffer_int(8);
    data.mapEnd = new Map();
    let nNum = MsgTool.pop_buffer_int(16);
    for(let  i = 0; i < nNum; i++) {
        let nCid  = MsgTool.pop_buffer_int(8);
        let OneData = new DzpkEndInfo;
        OneData.nCardType  = MsgTool.pop_buffer_int(8);
        OneData.nCoin  = MsgTool.pop_buffer_int(32);
        let nCardNum  = MsgTool.pop_buffer_int(16);
        for(let  j = 0; j < nCardNum; j++) {
            OneData.nArrayHandCard[j] = MsgTool.pop_buffer_int(8);
        }
        let nLastCardNum  = MsgTool.pop_buffer_int(16);
        for(let k = 0; k < nLastCardNum; k++) {
            OneData.nArrayMaxCard[k] = MsgTool.pop_buffer_int(8);
        }
        data.mapEnd.set(nCid, OneData);
    }
    g_DepokerData.responseEnd(data);
};


 //S2C_POOL_LIST_END  = 41030,     //结束
s2c_PROTOCOL.S2C_41030 = function (MsgTool) {
    let data = new DzpkEndPoolMsg;
    let nNum = MsgTool.pop_buffer_int(16);
    data.mapPool = new Map();
    data.mapChairList = new Map();
    for (let  i = 0; i < nNum; i++) {
        let nPool = MsgTool.pop_buffer_int(8);
        let nCoin = MsgTool.pop_buffer_int(32);
        data.mapPool[nPool] = nCoin;
        let nShareNum = MsgTool.pop_buffer_int(16);
        let nArrayChairId = [];
        for(let j = 0 ; j< nShareNum; j++)
        {
            nArrayChairId[j] = MsgTool.pop_buffer_int(8);
        }
        data.mapChairList[nPool] = nArrayChairId;
    }
    g_DepokerData.responseEndPool(data);
};


s2c_PROTOCOL.S2C_41060 = function (Msgtool) {
    /*
    let dddddd = msgtool.pop_buffer_int(8);
    let nAccountID  = msgtool.pop_buffer_int(32);
    let strAccount  = msgtool.pop_buffer_constchar();
    let strTicket   = msgtool.pop_buffer_constchar();
    */
};