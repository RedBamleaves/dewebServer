/**
 * Created by Administrator on 2017/2/8.
 */

const cocos_widget = {
    VISION_DEF : 1.00,
    SER_SOCK_URL            : "www.dayingjiaol.com",//123.57.31.71
    //通用按钮背景
    p_btn_big_normal        : "btn_common_normal@2x.png",
    p_btn_big_selected      : "btn_common_selected@2x.png",
    p_btn_min_normal        : "btn_commin_normal@2x.png",
    p_btn_min_selected      : "btn_commin_selected@2x.png",
    p_btn_sml_normal        : "btn_comsml_normal@2x.png",
    p_btn_sml_selected      : "btn_comsml_selected@2x.png",
    p_btn_state_normal      : "btn_state_normal@2x.png",
    p_btn_state_selected    : "btn_state_selected@2x.png",
    p_btn_select_normal     : "btn_select_normal@2x.png",
    p_btn_select_selected   : "btn_select_selected@2x.png",
    p_btn_close_normal      : "btn_close_normal@2x.png",
    p_btn_close_selected    : "btn_close_selected@2x.png",
    p_btn_return_normal     : "btn_close_normal@2x.png",
    p_btn_return_selected   : "btn_close_selected@2x.png",
};
