/**
 * Created by Administrator on 2017/2/8.
 */

const c2s_PROTOCOL =
{
    //角色登录协议相关
    C2S_PLAYER_LOGON        : 10000,
    C2S_PLAYER_LOGOUT       : 10001,     //退出登录
    C2S_REQ_PLAYER_ID       : 10002,     //请求角色ID
    C2S_PLAYER_CREAT        : 10003,
    C2S_PLAYER_ENTER        : 10004,
    C2S_PLAYER_DEL          : 10005,         //删除角色
    C2S_PING                : 10006,               //心跳包
    C2S_PLAYER_LOGINED      : 10007,     //账号在别处已登录
    C2S_CHECK_ROLE_NAME     : 10010,    //检查名字是否重复

    //用户信息
    C2S_ROLE_INFO           : 13001,    //用户信息
    C2S_ADD_EXP             : 13002,      //增加经验
    C2S_LEVEL_UP            : 13003,     //升级
    C2S_CHECK_ROLE_INFO     : 13004,    //查询指定ID角色信息

    C2S_ACCOUNT_SERVER      : 60000,
    C2S_ACCOUNT_LOGIN       : 60001,
    C2S_ACCOUNT_REGISTER    : 60002,
    C2S_ACCOUNT_GUEST       : 60003,
    C2S_ACCOUNT_AMEND_PWD   : 60004,

    //Dzpk Protocol Begin
    C2S_TABLE_GAME_ENTER       :41000,    //进入游戏
    C2S_TABLE_GAME_JOIN		  :41001,	//加入
    C2S_TABLE_GAME_LEAVE       :41002,	//离开
    C2S_TABLE_GAME_START	      :41003,	//开始
    C2S_TABLE_GAME_ABANDON	  :41004,	//放弃
    C2S_TABLE_GAME_FILLED	  :41005,	//加注
    C2S_TABLE_GAME_OPENED	  :41006,	//开牌
    C2S_TABLE_GAME_STANDUP    :41007,	//站起
    C2S_TABLE_GAME_SITDOWN	  :41008,	//坐下
    C2S_TABLE_CHANGE           :41009,    //换桌
    C2S_TABLE_FEE              :41010,    //小费
    C2S_TABLE_USE_MAGIC       :41015,    //使用魔法道具
    C2S_TABLE_GAME_MEMBER     :41020,    //将自己信息发送给其它桌子上的玩家，
    C2S_TABLE_GAME_MBLIST	 :41021,	//发送玩家信息列表给自己
    C2S_TABLE_GAME_TIMER	     :41022,	//发送时间
    C2S_TABLE_GAME_CARD		 :41023,	//发送下一把牌
    C2S_TABLE_POOL_LIST       :41024,    //边池
    C2S_TABLE_SYNC_TAKE_SCORE :41025,    //同步筹码

    C2S_TABLE_SHOW_MY_HAND_CARD :41027,  //客户端玩家发送亮牌
    C2S_TABLE_HAND_CARD          :41028,    //玩家手中的牌
    C2S_TABLE_END                 :41029,    //结束时候发送
    C2S_POOL_LIST_END            :41030,     //结束
    C2S_DEPOKER_RECONNECT_JOIN : 41060     //从新加入
    //Dzpk Protocol End

};

const s2c_PROTOCOL = {};



