/**
 * Created by Administrator on 2017/2/16.
 */

const REQGRO_URL = 'http://127.0.0.1:3302/ip/geoposition';

var ipTools = ipTools || {};

ipTools.ReqGroposition = function (callback) {
    let http = HttpTool.create();
    http.url = REQGRO_URL;
    http.callback = function (status,responseText) {
        if(status === 200){
            callback(responseText);
        }
        else{
            cc.log('Http errors!');
            cc.log('Http responseText : ' + responseText);
        }
    };
    HttpTool.SendReq(http);
};