/**
 * Created by Administrator on 2017/2/20.
 */

var SDKListener = {};

// errorCode为0表示登录成功，从json中获取uuid和token传给游戏服务器做验证
// 如果errorCode为1则表示用户没有成功登录，需要游戏再次弹出登录界面
SDKListener.onLogin = function(/*int   */   errorCode,
                               /*String*/   json) {

};

// errorCode只会为0，收到此消息表示玩家主动登出了账号
SDKListener.onLogout = function(/*int   */ errorCode,
                                /*String*/ json) {

};

//errorCode为0表示支付操作完成，具体是否是有效充值要等游戏服务器收到通知为准
//errorCode为1表示玩家取消了支付
SDKListener.onPay = function(/*int   */errorCode,
                             /*String*/ json) {

};

//errorCode只会为0，收到此消息开始游戏的销毁操作
SDKListener.onQuit = function(/*int    */errorCode,
                              /*String*/ json) {
    //这个暂时在java中没有调用，java直接finish掉了，如果有其他操作，再调用这个函数
};