/**
 * Created by Administrator on 2017/2/15.
 */

var HttpTool = {};

HttpTool.create = function () {
    let http = cc.loader.getXMLHttpRequest();
    http.timeout = 15 * 1000;
    http.async = true;
    http.url = '';
    http.reqType = 'GET';

    http.onloadstart = ()=> {cc.log('http is loadstarted');};
    http.onabort     = ()=> {cc.log('http is aborted');};
    http.onload      = ()=> {cc.log('http is loading');};
    http.onloadend   = ()=> {cc.log('http is onloadending');};
    http.ontimeout   = ()=> {cc.log('http is onloadending');};
    http.onerror     = ()=> {cc.log('http is onloadending');};
    http.callback    = ()=> {cc.log('http is callback');};
    cc.log('create http!');
    return http;
};

HttpTool.SendReq = function (http) {
    http.open(http.reqType,http.url,http.async);
    if (cc.sys.isNative) {
        http.setRequestHeader("Accept-Encoding","gzip,deflate");
    }
    http.onreadystatechange = function (){
        if (http.readyState === 4) {
            let resText = http.responseText;
            cc.log('Http status : ' + http.status);
            if(http.status === 200 || http.status === 202){
                http.callback(http.status,resText);
            }
        }
    };
    http.send();
};