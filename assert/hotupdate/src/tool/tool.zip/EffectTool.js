/**
 * Created by Administrator on 2017/2/10.
 */

const ColorlessPic = 'res/select_role_edit.png';

cc.createEffect = function (
    fileBook,           //子文件夹
    effectName,         //特效文件名
    ftime,              //特效单次循环时间
    frame,              //帧数
    isCycle,            //是否循环
    isFrame,            //特效加载类型，true表示正常的缓存组织动作，false用于大尺寸特效，及切换帧配合内存管理
    update_time,        //循环间隔时间,若使用此参数,间隔时间不得小于0.05f
    play_delay)         //特效开始播放间隔时间,若使用此参数,间隔时间不得小于0.05f
{
    return new EffectTool(fileBook,effectName,ftime,frame,isCycle,isFrame,update_time,play_delay);
};

/*
 * isFrame:这个值是true的时候，当作正常精灵使用，
 * 如果是false，特效目标精灵就变成了 actionSp
 */

var EffectTool = cc.Sprite.extend({
    m_filename : '',
    m_filebook : '',
    m_effectname : '',
    m_ftime : 0.0,
    m_frame : 0,
    m_isCycle : false,
    m_isFrame : true,
    UpdateTime: 0.0,
    m_FrameStay:0,
    m_play_delay : 0.0,
    m_Count : 0,            //当前帧数

    actionSp:null,
    thisSize:cc.SizeZero(),
    FrameSize:cc.SizeZero(),
    isRemove:false,

    ctor:function (fileBook,effectName,ftime,frame,isCycle,isFrame,update_time,play_delay) {
        this._super();
        this.m_play_delay = (play_delay !== undefined)?play_delay : 0.0;
        this.m_FrameStay = 0;
        this.UpdateTime = (update_time !== undefined)?update_time : 0.0;
        this.isRemove = true;
        this.m_filebook = fileBook;
        this.m_effectname = effectName;
        this.m_ftime = ftime;
        this.m_frame = frame;
        this.m_isCycle = (isCycle !== undefined)?isCycle : false;
        this.m_isFrame = (isFrame !== undefined)?isFrame : true;
        this.m_Count = 0;           //当前帧数
        this.actionSp = null;
        this.thisSize = cc.size(250,250);
        this.FrameSize = cc.size(250,250);
        let thisptr = this;

        let filename = '';
        if(this.m_isFrame){
            this.m_filename = this.m_effectname;
            this.initWithSpriteFrame(cc.spriteFrameCache.getSpriteFrame(this.m_effectname + '_00@2x.png'));
            this.setVisible(false);
            //let actall = this.getFrameAction();
            let actionArray = [
                cc.delayTime(this.m_play_delay),
                cc.callFunc(function () {
                    thisptr.setVisible(true);
                    thisptr.ActionEffect();
                },this)
            ];
            this.runAction(cc.sequence(actionArray));
        }else{
            this.initWithFile(ColorlessPic);
            this.m_filename = this.m_effectname;
            filename = this.m_filebook + '/' + this.m_filename + '_' + pad(parseInt((this.m_frame - 1)/2),2) + '@2x.png';
            this.thisSize = this.getContentSize();
            this.FrameSize = (new cc.Sprite(filename)).getContentSize();
            cc.textureCache.removeTextureForKey(filename);
            filename = this.m_filebook + '/' + this.m_filename + '_' + pad(this.m_FrameStay,2) + '@2x.png';

            this.actionSp = cc.Sprite.create(filename);
            this.actionSp.setAnchorPoint(cc.p(0.5,0.5));
            this.actionSp.setPosition(this.thisSize.width/2,this.thisSize.height/2);
            this.addChild(this.actionSp,1);

            let actionArray = [
                cc.delayTime(this.m_play_delay),
                cc.callFunc(function () {
                    thisptr.UpdateEffect();
                },this),
            ];
            this.runAction(cc.sequence(actionArray));
        }
    },

    setFrameStay : function(_t)
    {
        this.m_FrameStay = _t;
    },
    //通过精灵缓存帧
    ActionEffect : function()
    {
        let thisptr = this;
        let actall = this.getFrameAction();
        if(this.m_isCycle && this.UpdateTime - 0.0 <= 0.04)
        {
            let rep = cc.repeatForever(actall);
            this.runAction(rep);
        }
        else if(this.m_isCycle && this.UpdateTime - 0.0 >= 0.04)
        {
            let seq = cc.sequence(
                actall,
                cc.callFunc(function()
                {
                    let allnames = "";
                    allnames = thisptr.m_filename + '_' + pad(thisptr.m_FrameStay,2) + '@2x.png';
                    let spf = cc.spriteFrameCache.getSpriteFrame(allnames);
                    if(!spf)return;
                    thisptr.setSpriteFrame(spf);
                },this),
                cc.delayTime(this.UpdateTime)
            );
            let rep = cc.repeatForever(seq);
            this.runAction(rep);
        }
        else
        {
            this.removeFromParent();
        }
    },
    //通过文件,用于大尺寸帧
    UpdateEffect : function(dt)
    {
        let filename = "";
        filename = this.m_filebook + '/' + this.m_filename + '_00@2x.png';
        this.actionSp.setTexture(filename);

        let allnames = "";
        let delayTime = 0.0;
        ++this.m_Count;
        allnames = this.m_filebook + '/' + this.m_filename + '_' + pad(this.m_Count,2) + '@2x.png';
        cc.textureCache.addImage(allnames);
        if(this.m_ftime > 0)
        {
            delayTime = this.m_ftime * 1.0/this.m_frame;
        }
        else
        {
            delayTime = 2.0/15.0;
        }
        this.setVisible(true);
        this.schedule(this.updateTexture, delayTime);
    },

    updateTexture : function(dt)
    {
        let allnames = "";
        allnames = this.m_filebook + '/' + this.m_filename + '_' + pad(this.m_Count,2) + '@2x.png';

        this.actionSp.setTexture(allnames);
        this.actionSp.setContentSize(this.FrameSize);
        this.actionSp.setAnchorPoint(cc.p(0.5,0.5));
        this.actionSp.setPosition(this.thisSize.width/2,this.thisSize.height/2);

        let temp_count = this.m_Count;
        if(temp_count == 0)
        {
            temp_count = this.m_frame - 1;
        }
        allnames = this.m_filebook + '/' + this.m_filename + '_' + pad(temp_count - 1,2) + '@2x.png';
        cc.textureCache.removeTextureForKey(allnames);

        ++this.m_Count;
        if(this.m_Count >= this.m_frame && !this.m_isCycle)
        {
            this.unschedule(this.updateTexture);
            if(this.isRemove)
            {
                this.removeFromParent();
            }
        }
        else if(this.m_Count >= this.m_frame && this.m_isCycle && this.UpdateTime - 0.0 >= 0.04)
        {
            this.m_Count = 0;
            //this.setVisible(false);
            allnames = this.m_filebook + '/' + this.m_filename + '_' + pad(this.m_FrameStay,2) + '@2x.png';
            this.actionSp.setTexture(allnames);
            this.unschedule(this.updateTexture);
            this.scheduleOnce(this.UpdateEffect, this.UpdateTime);
        }
        else if(this.m_Count >= this.m_frame && this.m_isCycle && this.UpdateTime - 0.0 <= 0.04)
        {
            this.m_Count = 0;
            allnames = this.m_filebook + '/' + this.m_filename + pad(this.m_Count,2) + '@2x.png';
            cc.textureCache.addImage(allnames);
        }
        else
        {
            allnames = this.m_filebook + '/' + this.m_filename + pad(this.m_Count,2) + '@2x.png';
            cc.textureCache.addImage(allnames);
        }
    },

    getFrameAction : function()
    {
        let lqarr = [];
        let allnames = "";
        for (let i = 0; i < this.m_frame; i++)
        {
            allnames = this.m_filename + '_' + pad(i,2) + '@2x.png';
            let spf = cc.spriteFrameCache.getSpriteFrame(allnames);
            if(!spf)continue;
            lqarr.push(spf);
        }
        let animation = new cc.Animation(lqarr,this.m_frame);
        if(this.m_ftime > 0)
        {
            animation.setDelayPerUnit(this.m_ftime * 1.0/this.m_frame);
        }
        else
        {
            animation.setDelayPerUnit(2.0/15.0);
        }
        animation.setRestoreOriginalFrame(true);
        animation.setLoops(1);
        return cc.animate(animation);
    },

    getActionSp : function()
    {
        return this.actionSp;
    },

    setIsRemove : function (_t) {
        this.isRemove = _t;
    }
});