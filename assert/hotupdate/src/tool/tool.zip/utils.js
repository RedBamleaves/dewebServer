'use strict';
//字符串相关 ON------------------------------------------------------------------------
var CHARSET_HUMAN_FRIENDLY = 'abcdefhjkmnpqrstuvwxyz1234567890';
var CHARSET_LOWERCASE = 'abcdefghijklmnopqrstuvwxyz';
var CHARSET_UPPERCASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
var CHARSET_DIGITS = '1234567890';

//判断一个字符是不是中文
var isChinese = function(c)
{
    return c >= '\u4E00' && c <= '\u9FFF';
}
//获得字符串长度 中文是2 英文是1 
var getStringDisplayLength = function (s) {
    var n = 0;
    var i;
    for (i = 0; i < s.length; i++) {
        n += isChineseChar(s[i]) ? 2 : 1;
    }
    return n;
};
/**
 *
 * @param num      需要千分位转换的number
 * @returns {*|string}
 */
var thousandBitSeparator = function (num) {
    var numStr = num.toString();
    var inter  = Math.floor(num);
    num = (inter || 0).toString();
    var decial = numStr.substring(num.length);
    var result = '';
    var count = 1 ;
    while (num.length > 3) {
        result = ',' + num.slice(-3) + result;
        num = num.slice(0, num.length - 3);
    }
    if (num) { result = num + result + decial; }
    return result;
};
/**
 *
 * @param num      金币数字转换  1000 =》1000，   100000 = 》 10.00 万 ， 100000000 =》 1 .00亿
 * @returns {string}
 */
var makeGoldStr = function(num){
    var glodNum = 0;
    var glodStr = "";
    if(num >= 100000000){
        glodNum = (num/100000000);
        glodStr = glodNum.toFixed(2).toString()+"亿";
    }
    else if (num >= 10000){
        glodNum = (num/10000);
        glodStr = glodNum.toFixed(2).toString()+"万";
    }
    else {
        glodNum = num;
        glodStr = glodNum.toString();
    }
    return glodStr;
};
//中文转Utf-8
var GBKToUTF8 = function(pValue){
    return pValue.replace(/[^\u0000-\u00FF]/g,function($0){return escape($0).replace(/(%u)(\w{4})/gi,"&#x$2")});
};
var UTF8ToGBK = function(pValue){
    return unescape(pValue.replace(/&#x/g,'%u').replace(/\\u/g,'%u').replace(/;/g,''));
};



/**
 * 生成随机字符串
 * @param {number} len 生成的字符串长度
 * @param {string} charset 
 * @returns {string}
 */
var randomString = function (len, charset) {
    var chars = [];
    var i;
    for (i = 0; i < len ; i++) {
        chars.push(charset[randInt(charset.length)]);
    }
    return ''.join(chars);
};

/**
 * @param {ArrayBufferView} buffer
 * @returns {string}
 */
var bufferToString = function(buffer) {
    return String.fromCharCode.apply(null, new Uint8Array(buffer));
};

/**
 * @param {string} string
 * @returns {ArrayBuffer}
 */
var stringToBuffer = function(string) {
    var buffer = new ArrayBuffer(string.length);
    var uint8Array = new Uint8Array(buffer);
    var i;
    for(i = 0; i < string.length; i ++) {
        uint8Array[i] = string.charCodeAt(i);
    }
    return buffer;
};
//去掉首位c字符
var stringTrim = function(str, c){
    return str.replace(eval("/^" + c + "+|" + c + "+$/gi"), "");
};

// return time string, such as "04/10/14 05:17"
var convertMSToDateString = function (ms) {
    var date = new Date(ms);
    var minutes = date.getMinutes();

    return (date.getFullYear() - 2000) + "/" + (date.getMonth() + 1) + "/" + date.getDate() + " " +
        date.getHours() + ":" + (minutes < 10 ? "0" : "") + minutes;
};
//秒转时间字符串 return time string, such as "1d 10:10:10"
var secondsToDHMS = function (seconds) {
    seconds = Math.floor(seconds);
    if (seconds < 0) seconds = 0;
    var s = seconds % 60;
    var tmp = Math.floor(seconds / 60);
    var m = tmp % 60;
    tmp = Math.floor(tmp / 60);
    var h = tmp % 24;
    var d = Math.floor(tmp / 24);

    var r = '' + s;
    r = (s > 9 ? ":" : ":0") + r;
    r = m + r;
    r = (m > 9 ? "" : "0") + r;
    if (h > 0) {
        r = h + ":" +  r;
        r = (h > 9 ? "" : "0") + r;
    }
    if (d > 0) {
        if (s === 0 && m === 0 && h === 0) {
            r = d + "d";
        } else {
            r = d + "d" + " " + r;
        }
    }
    return r;
};
var getValueByRichText = function(str)
{
    var result = str.replace(/<[^>]+>/g,"")
    return result;
};
//字符串相关 OFF------------------------------------------------------------------------

//时间相关 ON---------------------------------------------------------------------------
/**
 * UTC 1970开始的秒数，与时区无关
 * @returns {number}
 */
var time = function () {
    return parseInt(Date.now() / 1000.0);
};

/**
 * 时区，范围为[-12,12]。例如中国为 8
 * @returns {number}
 */
var getTimeZone = function () {
    var offset = new Date().getTimezoneOffset();
    return parseInt(Math.round(offset / -60));
};

/**
 * UTC时间，当日凌晨0:00的毫秒数。
 * @param {number} 时间戳，毫秒
 */
var getUtcMidnightTime = function (timeMs) {
    var d = new Date(timeMs);
    d.setUTCHours(0);
    d.setUTCMinutes(0);
    d.setUTCSeconds(0);
    d.setUTCMilliseconds(0);
    return d.getTime();
};
/**
 * 获取指定时区的午夜时间
 * @param {number} timeMS 毫秒
 * @param {number} timeZone 时区 [-12,12]
 * @returns {number}
 */
var getMidnightTimeOfTimezone = function (timeMS, timeZone) {
    /**
     * 以 +8 区为例, delta=8
     * UTC       16           0            8
     *  +8       0            8            16
     * ----------+------------+------------+-----
     *           A            B  D^        C
     * D = timeMS
     * D + delta = timeMS + delta 在UTC的0点为 B
     * D 在+8区的0点为 B - delta = A
     *
     */

    var delta = timeZone * 3600 * 1000;
    return getUtcMidnightTime(timeMS + delta) - delta;
};

var getLocalMidnightTime = function(timeMs){
    var date = new Date(timeMs);
    date.setHours(0);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
    return date.getTime();
};
var isLeapYear = function(year) { 
    return (year % 4 === 0) && (year % 100 !== 0 || year % 400 === 0); 
};
var getDaysByYandM = function(year,month){
    if(isLeapYear(year))
    {
        if(month === 2){
            return 29;
        }
        else if(month === 1||month === 3||month === 5||month === 7||month === 8||month === 10|| month === 12){
            return 31;
        }
        else{
            return 30;
        }
    }
    else
    {
        if(month === 2){
            return 28;
        }
        else if(month === 1||month === 3||month === 5||month === 7||month === 8||month === 10|| month === 12){
            return 31;
        }
        else{
            return 30;
        }
    }
};
//时间相关 OFF---------------------------------------------------------------------------

/**
 * 返回[a, b)之间的随机整数。
 * 如果b未定义，则返回[0, a)之间的随机整数。
 * @param {number} a
 * @param {number=} opt_b
 * @returns {number}
 */
var randInt = function (a, opt_b)
{
    if (a == opt_b){
        return a;
    }
    var b = opt_b;
    if (b === undefined) {
        b = a;
        a = 0;
    }
    return Math.floor(Math.random() * (b - a) + a);
}
/*
    随机bool
*/
var randBool = function () {
    return 1 == Math.round(Math.random());
};
/**
 * 随机数组中的某个元素
 */
var randChoice = function (array) {
    var index = randInt(0, array.length);
    return array[index];
};
//删除数组重复元素
var unique = function (array) {
    var tmp = [];
    for(var m in array) {
        tmp[array[m]] = 1;
    }
    //再把键和值的位置再次调换
    var tmparr = [];
    for(var n in tmp){
        tmparr.push(n);
    }
    return tmparr;
};

/*
 *  pad(3,6); //000003
 */

var pad = function (num,n) {
    let y ='00000000000000000000000000000'+ num; //爱几个0就几个，自己够用就行
    return y.substr(y.length - n);
};
