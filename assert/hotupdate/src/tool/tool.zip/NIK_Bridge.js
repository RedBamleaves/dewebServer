/**
 * Created by Administrator on 2017/2/20.
 */

var NIK_Bridge = {};

//登录,初始化成功后才可以调用此接口
//    参数说明：
//    lineID ：游戏默认登录的游戏线（区服）ID，如果没有，可以随意填写，但不能为空，等选择之后再调用selectLine设置正确的游戏线（区服）ID
//    lineName ：游戏线（区服）名称
NIK_Bridge.login = function(/*String*/  lineID,
                            /*String*/  lineName){
    if(sys.os === 'android'){
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "login",
            "(Ljava/lang/String;Ljava/lang/String;)V",
            lineID,lineName);
    }else if(sys.os === 'ios'){
        jsb.reflection.callStaticMethod("NIK_Bridge", "login");
    }
};

NIK_Bridge.selectLine = function(/*String*/  lineID,
                                /*String*/  lineName){
    if(sys.os === 'android'){
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "selectLine",
            "(Ljava/lang/String;Ljava/lang/String;)V",
            lineID,lineName);
    }else if(sys.os === 'ios'){
        jsb.reflection.callStaticMethod("NIK_Bridge", "selectLineID:lineName:",lineID,lineName);
    }

};

//初始化成功后才可以调用此接口。需要根据不同的渠道执行不同的策略
NIK_Bridge.quit = function(){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "quit",
            "()V");
    }
};
//初始化成功后才可以调用此接口。调用之后会收到onLogout回调通知，再次调用登录界面时不会自动登录
NIK_Bridge.logout = function(){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "logout",
            "()V");
    }
};
//初始化成功后才可以调用此接口。调用之后会弹出用户中心界面，如果未登录则是弹出登录界面，cp可以在登录界面或者设置界面添加按钮调用此接口
NIK_Bridge.userCenter = function(){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "userCenter",
            "()V");
    }else if(sys.os === 'ios'){
        jsb.reflection.callStaticMethod("NIK_Bridge", "userCenter");
    }
};
//登陆成功后上传角色信息
//        参数说明：
//        roleID ：角色ID
//        roleName ：角色名称
//        roleLevel ：角色等级
//        lineID ：线服ID
//        lineName ：线服名称
//        guildName ：公会名称
//        roleCT ：角色创建Unix时间戳（秒）
//        createRole ： 是否创建角色操作，默认为false，即不是刚创建的新角色
NIK_Bridge.roleLoggedIn = function(/*String*/   roleID,
                                   /*String*/   roleName,
                                   /*String*/   roleLevel,
                                   /*String*/   lineID,
                                   /*String*/   lineName,
                                   /*String*/   guildName,
                                   /*long  */   roleCT,
                                   /*boolean*/  createRole){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "roleLoggedIn",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)V",
            roleID, roleName, roleLevel, lineID, lineName, guildName, roleCT, createRole);
    }
};
//角色升级后上传角色信息
//        参数说明：
//        roleID ：角色ID
//        roleName ：角色名称
//        roleLevel ：角色等级
//        lineID ：线服ID
//        lineName ：线服名称
//        guildName ：公会名称
//        roleCT ：角色创建Unix时间戳（秒）
NIK_Bridge.roleLevelup = function(/*String*/  roleID,
                                  /*String*/  roleName,
                                  /*String*/  roleLevel,
                                  /*String*/  lineID,
                                  /*String*/  lineName,
                                  /*String*/  guildName,
                                  /*long  */  roleCT){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "roleLevelup",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V",
            roleID, roleName, roleLevel, lineID, lineName, guildName, roleCT);
    }
};
//切换账号
//        参数说明：
//        lineID ：线服ID
//        lineName ：线服名称
NIK_Bridge.switchAccount = function(/*String*/ lineID,
                                    /*String*/ lineName){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge",
            "switchAccount",
            "(Ljava/lang/String;Ljava/lang/String;)V",
            lineID, lineName);
    }else if(sys.os === 'android'){
        jsb.reflection.callStaticMethod("NIK_Bridge", "switchAccount");
    }
};
//创建角色
//        参数说明：
//        roleID ：角色ID
//        roleName ：角色名称
//        roleLevel ：角色等级
//        lineID ：线服ID
//        lineName ：线服名称
//        guildName ：帮派名称
//        roleCT ：角色创建Unix时间戳（秒）
NIK_Bridge.createRole = function(/*String*/  roleID,
                                 /*String*/   roleName,
                                 /*String*/   roleLevel,
                                 /*String*/   lineID,
                                 /*String*/   lineName,
                                 /*String*/   guildName,
                                 /*long  */   roleCT){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod(
            "org/cocos2dx/javascript/NIK_Bridge", "createRole",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V",
            roleID, roleName, roleLevel, lineID, lineName, guildName, roleCT);
    }
};
//进入游戏（选择角色后，进入到游戏主场景）
NIK_Bridge.enterGame = function(){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod("org/cocos2dx/javascript/NIK_Bridge", "enterGame", "()V");
    }
};
//返回SDK的版本号（单独接入拟酷渠道时返回拟酷SDK版本号，接入拟酷平台打包全部渠道时返回各自渠道版本号）
NIK_Bridge.getVersion = function(){
    if(sys.os === 'android') {
        return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/NIK_Bridge", "getVersion", "()Ljava/lang/String;");
    }else if(sys.os === 'ios'){
        return  jsb.reflection.callStaticMethod("NIK_Bridge", "getSDKVersion");
    }
};
//返回SDK的渠道标识ID（单独接入拟酷渠道时无需使用此方法，接入拟酷平台打包全部渠道时有用）
NIK_Bridge.getPlatformID = function(){
    if(sys.os === 'android') {
        return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/NIK_Bridge", "getVersion", "()I");
    }else if(sys.os === 'ios'){
        return  jsb.reflection.callStaticMethod("NIK_Bridge", "getPlatformID");
    }
};
//返回渠道是否有用户中心功能（单独接入拟酷渠道时无需使用此方法，接入拟酷平台打包全部渠道时有用）
NIK_Bridge.hasUserCenter = function(){
    if(sys.os === 'android') {
        return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/NIK_Bridge", "hasUserCenter", "()Z");
    }
};
//返回渠道是否有退出界面功能（单独接入拟酷渠道时无需使用此方法，接入拟酷平台打包全部渠道时有用）
NIK_Bridge.hasQuitPanel = function(){
    if(sys.os === 'android') {
        return jsb.reflection.callStaticMethod("org/cocos2dx/javascript/NIK_Bridge", "hasQuitPanel", "()Z");
    }
};
//拉起支付界面时，创建预订单
NIK_Bridge.pay = function(/*int   */    _Amount,
                          /*int   */    _ExchangeRatio,
                          /*String*/    _MoneyName,
                          /*String*/    _Extra,
                          /*String*/    _ProductId,
                          /*String*/    _ProductName){
    if(sys.os === 'android') {
        jsb.reflection.callStaticMethod("org/cocos2dx/javascript/NIK_Bridge", "pay",
            "(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
            _Amount, _ExchangeRatio, _MoneyName, _Extra, _ProductId, _ProductName);
    }else if(sys.os === 'ios'){
        jsb.reflection.callStaticMethod("NIK_Bridge", "pay:productID:amount:exchangeRate:extra",
            _MoneyName, _ProductId, _Amount, _ExchangeRatio, _Extra);
    }
};