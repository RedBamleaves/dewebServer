/**
 * Created by Administrator on 2017/2/20.
 */


var FeedbackTips = {};

FeedbackTips.path = 'res/test/';

FeedbackTips.showTips = function (msg,parentNode) {
    cc.log('都TM来搞事情!');
    let strNotice = msg;
    let frame_sp = new cc.Sprite();
    frame_sp.setContentSize(cc.size(373 * 2,70));
    frame_sp.setPosition(cc.p(cc.winSize.width/2, cc.winSize.height/2 - 100));
    frame_sp.setAnchorPoint(cc.p(0.5,0.5));

    let frame_left = new cc.Sprite(FeedbackTips.path + "exchange_julu_di1.png");
    frame_left.setAnchorPoint(cc.p(0,0));
    frame_left.setPosition(cc.p(frame_sp.getContentSize().width/2,0));
    frame_sp.addChild(frame_left);

    let frame_right = new cc.Sprite(FeedbackTips.path + "exchange_julu_di1.png");
    frame_right.setAnchorPoint(cc.p(1,0));
    frame_right.setFlippedX(true);
    frame_right.setPosition(cc.p(frame_sp.getContentSize().width/2,0));
    frame_sp.addChild(frame_right);

    let width_sp = frame_sp.getContentSize().width;
    let labelMsg = new cc.LabelTTF(strNotice, "Arial", 28);
    labelMsg.setPosition(cc.p(frame_sp.getContentSize().width/2, frame_sp.getContentSize().height/2));
    labelMsg.setAnchorPoint(cc.p(0.5,0.5));
    labelMsg.enableShadow(cc.color(43,38,79),cc.size(1,2),2);
    labelMsg.setColor(cc.color(235,235,235));
    frame_sp.addChild(labelMsg,2);

    if(labelMsg.getContentSize().width - width_sp > -20)
    {
        labelMsg.setScale((width_sp - 20)/labelMsg.getContentSize().width);
    }

    parentNode.addChild(frame_sp,999);
    let pMoveBy = cc.moveBy(0.8, cc.p(0, 80));
    let pFadeOut = cc.fadeOut(0.8);
    let pSpawn = cc.spawn(pMoveBy, pFadeOut);
    let pDelay = cc.delayTime(0.2);
    frame_sp.runAction(cc.sequence(pDelay,pSpawn,cc.callFunc( function () {
        frame_sp.removeFromParent();
    })));
};
